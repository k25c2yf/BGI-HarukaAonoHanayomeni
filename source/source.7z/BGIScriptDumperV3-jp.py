# -*- coding: utf-8 -*-
# For Windows OS Only....
# 支援用"\r"符號取代為換行符，解決換行截斷問題
# 支持舊版本的格式

import sys
import os
import struct
import codecs
import unicodedata

if len(sys.argv) < 2:
    print("error\n")
    print(sys.argv[0] + " <script\>")
    quit()

SC = sys.argv[1]
EX = sys.argv[1] + ".txt"

try:
    SCFile = open(SC, 'rb')
except FileNotFoundError:
    print(SC + " Error!\tCan't find file!")
    exit()
except:
    print("Error!")
    exit()

SCFile.seek(0)
test = SCFile.read(20)

# 檢查文件是否為新格式
magic = b"BurikoCompiledScriptVer1.00\x00"
if test[:0x1C] == magic:
    header_length = 0x1C + struct.unpack("<I", test[0x1C:0x20])[0]
else:
    header_length = 0

SCFile.seek(header_length)
test = SCFile.read(4)
while not test == b'\x01\x00\x00\x00':
    test = SCFile.read(4)
SCFile.seek(-4, 1)
offset = SCFile.tell()

while not test == b'\x03\x00\x00\x00':
    test = SCFile.read(4)
locate = struct.unpack('L', SCFile.read(4))[0]
SCFile.seek(locate + offset)
textInFile = SCFile.read()
SCFile.seek(offset)
TXFile = open(EX, 'w', 1, "UTF_8")
textOffset = locate
end = locate + offset

while SCFile.tell() < end:
    test = SCFile.read(4)
    if test == b'\x03\x00\x00\x00':
        address = SCFile.tell()
        locate = struct.unpack('L', SCFile.read(4))[0]
        textLocate = locate - textOffset
        text = textInFile[textLocate:textInFile.find(b'\x00', textLocate)]

        try:
            text.decode('Shift-JIS')
        except:
            text = b''
            textUTF = u""
        else:
            textUTF = text.decode('Shift-JIS')

            # Replace "\n" with "\r" to address the newline issue
            textUTF = textUTF.replace("\n", "\\r").replace("\x0A", "\\r")

            if unicodedata.east_asian_width(textUTF[0]) != 'Na':
                TXTemp = '●' + '%.6d' % address + u'●' + textUTF + u'\n'
                TXFile.write(TXTemp)

SCFile.close()
TXFile.close()
print("Finished!")
