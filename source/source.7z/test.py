import sys
import struct
import codecs


def main():
    # 检查命令行参数是否存在
    if len(sys.argv) == 1:
        print("Usage: ScriptEncoder.py <input_file.txt>")
        input("Press any key to continue...")
        return

    # 获取输入文件的路径
    file_input = sys.argv[1]

    # 加载脚本文件
    with open(file_input.replace(".txt", ""), "rb") as file:
        script_buffer = file.read()

    # 加载翻译文件
    with codecs.open(file_input, "r", encoding="utf-8-sig") as file:
        lines = file.read().replace("\r\n", "\n").split("\n")
    if len(lines) == 0:
        return

    # header_length 包括 MAGIC 和 @[0x1C]
    header_length = 0

    # 检查文件是否为新格式
    # 最重要的是新格式有一个魔术字符串 "BurikoCompiledScriptVer1.00\x00"
    # 新格式和旧格式的区别在于，旧格式中没有 HEADER，而 HEADER 的长度在 [0x1C] 处以 DWORD 形式描述。
    magic = b"BurikoCompiledScriptVer1.00\x00"
    if script_buffer[:0x1C] == magic:
        header_length = 0x1C + struct.unpack("<I", script_buffer[0x1C:0x20])[0]

    # 获取原始缓冲区中的控制字节
    control_stream = script_buffer[header_length:header_length + get_smallest_offset(lines)]

    # 开始处理
    text_stream = bytearray()
    for line in lines:
        # 跳过空行
        if not line.strip():
            continue

        info = get_line_info(line)
        control_stream += struct.pack("<I", info[0])
        text_stream += get_text(line).encode("cp936") + b"\x00"

    # 构建新的脚本文件
    with open(file_input + ".new", "wb") as file:
        # 写入 HEADER
        if header_length != 0:
            file.write(script_buffer[:header_length])
        # 写入控制字节
        file.write(control_stream)
        # 写入文本字节
        file.write(text_stream)


def get_smallest_offset(lines):
    return min(get_line_info(line)[1] for line in lines if line.strip()) if lines else 0


def get_line_info(line):
    line_info = line[line.index("<") + 1:line.index(">")].split(",")
    return [int(x) for x in line_info]


def get_text(line):
    return line[line.index(">") + 1:].replace(r"\n", "\x0A")


if __name__ == "__main__":
    main()
